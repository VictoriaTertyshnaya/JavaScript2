const goods = [
    { id: 1, title: 'Shirt', price: 150 },
    { id: 2, title: 'Socks', price: 50 },
    { id: 3, title: 'Jacket', price: 350 },
    { id: 4, title: 'Shoes', price: 250 },
];
const renderGoodsItem = (title = "", price, img = 'img/shirt.jpg" alt="shirt') =>
    `<div class="goods-item">
      <img class='goods-item-img' src="${img}">
        <div class="goods-item__content">
          <h3 class='goods-item-name'>Название товара: ${title}</h3>
          <p class='goods-item-price'>Цена товара: ${price} руб.</p>
          <button class="btn_goods-btn">Купить</button>
      </div>
    </div>`;

const renderGoodsList = (list) => {
    let goodsList = list.map(item => renderGoodsItem(item.title, item.price, item.img));
    document.querySelector('.goods-list').innerHTML = goodsList.join('');
}

renderGoodsList(goods);